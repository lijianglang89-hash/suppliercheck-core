/**
 * 文件安全工具集（需求「十一、文件安全」）。
 *
 * 这里集中处理所有「不信任用户输入」的逻辑：
 * - 文件名清洗：剥离路径分隔符、控制字符、保留名、超长名；
 * - 扩展名不信任：存储用的扩展名由 MIME 白名单反查得出；
 * - 魔数嗅探：不只看 Content-Type，真实字节必须与声明类型一致；
 * - 存储键生成：一律 UUID，杜绝路径穿越与文件名注入。
 */
import { createHash, randomUUID } from "node:crypto";

import { errors } from "@/lib/errors";

/** 允许上传的 MIME 白名单。扩展名由这里反查，不读用户提供的扩展名。 */
export const ALLOWED_MIME_TYPES: Readonly<Record<string, string>> = {
  "application/pdf": ".pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
  "image/png": ".png",
  "image/jpeg": ".jpg",
  "application/zip": ".zip",
};

export const ALLOWED_MIME_TYPE_LIST = Object.keys(ALLOWED_MIME_TYPES);

/**
 * 扩展名 → MIME 的反向表。
 *
 * 用途只有一个：zip 包内条目没有 Content-Type 可信任（压缩包不会为每个条目带类型），
 * 只能按扩展名猜测。猜出来后仍然要走**同一份白名单**，猜不出或不在白名单里的条目直接跳过，
 * 不给「压缩包绕过类型校验」留口子。
 */
export const EXTENSION_TO_MIME: Readonly<Record<string, string>> = Object.freeze(
  Object.fromEntries(
    Object.entries(ALLOWED_MIME_TYPES).map(([mime, extension]) => [extension, mime]),
  ),
);

/** 按扩展名猜 MIME；不在白名单内返回 undefined（调用方应据此拒绝）。 */
export function resolveMimeForExtension(filename: string): string | undefined {
  const extension = extractExtension(filename);
  return extension ? EXTENSION_TO_MIME[extension] : undefined;
}

/** 文件名的最大长度（字符）。超出会被截断保留后缀。 */
const MAX_FILENAME_LENGTH = 120;

/** Windows 保留设备名，出现在文件名中会导致不可预期的行为。 */
const WINDOWS_RESERVED_NAMES =
  /^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$/i;

/** 文件名中不允许出现的字符：路径分隔符、控制字符、路径穿越序列。 */
const ILLEGAL_FILENAME_CHARS = /[\\/:*?"<>|\u0000-\u001f\u007f]/g;

/**
 * 清洗文件名，返回可安全展示与记录的版本。
 * 注意：清洗结果**只用于展示与审计**，绝不用于拼接存储路径。
 */
export function sanitizeFilename(input: string): string {
  const trimmed = (input ?? "").trim();
