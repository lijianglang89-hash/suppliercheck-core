  const storage = getStorageProvider();
  const localPath = storage.localPathFor?.(parent.storagePath);

  if (!localPath) {
    // 换对象存储后需要先落临时文件才能展开；当前如实跳过，不让上传整体失败。
    return [];
  }

  /*
   * ⚠️ 规划（planZipExtraction）必须和展开一起包在 try 里。
   *
   * 曾经它单独在 try 之外：包结构不合法时它抛错，catch 接不到，错误一路冒泡到上传路由。
   * 结果是「父文档已落库、但 enqueueMany 从未执行」—— 状态永远停在 UPLOADED，
   * 界面上留下一个不会自己消失、永远转圈的幽灵任务。这是标准的客诉制造机。
   *
   * 修法：任何一步失败都把**父文档扭成 FAILED**（并记录原因），让状态机闭环。
   * 已经展开出来的子文档仍然返回 —— 它们是完整可用的资料，没理由跟着陪葬。
   */
  let plan: Awaited<ReturnType<typeof planZipExtraction>>;
  const jobId = await startJob({
    workspaceId: parent.workspaceId,
    documentId: parent.id,
    jobType: UNZIP_JOB_TYPE,
  });

  const children: DocumentRow[] = [];

  try {
    plan = await planZipExtraction(localPath);
    if (plan.accepted.length === 0) {
      await finishJob({ jobId, status: "SUCCEEDED" });
      return [];
    }

    await extractZipEntries(localPath, plan.accepted, async (entryPlan, stream) => {
      const childId = newId();
      const childKey = buildStorageKey({
        workspaceId: parent.workspaceId,
        documentId: childId,
        mimeType: entryPlan.mimeType,
      });

      // 逐条串行解压：一次只有一条条目流在内存/磁盘管道里。
      // maxBytes 用条目声明的解压大小 —— 元数据可以撒谎，所以由存储层按**实际字节**再卡一次。
      const stored = await storage.uploadStream({
        key: childKey,
        stream,
        contentType: entryPlan.mimeType,
        maxBytes: entryPlan.uncompressedSize,
      });

      children.push(
        await createDocument({
          // 同上：子文档的 id 必须与磁盘上那份文件的存储键一致。
          id: childId,
          workspaceId: parent.workspaceId,
          originalFilename: `${parent.safeFilename}/${entryPlan.entryName}`,
          safeFilename: entryPlan.safeFilename,
          mimeType: entryPlan.mimeType,
          extension: resolveExtensionForMime(entryPlan.mimeType),
          size: stored.size,
          checksum: stored.checksum,
          storagePath: childKey,
          createdBy: parent.createdBy,
          parentDocumentId: parent.id,
        }),
      );
    });

    await finishJob({ jobId, status: "SUCCEEDED" });
  } catch (error) {
    const appError = toAppError(error);

    // 关键兜底：父文档必须离开 UPLOADED，否则它会永远卡在「待处理」。
    await markDocumentFailed(parent.id).catch((markError: unknown) => {
      logger.error("标记压缩包展开失败状态时出错", { documentId: parent.id, markError });
    });

    await finishJob({
      jobId,
      status: "FAILED",
      errorCode: appError.code,
      errorMessage: appError.message.slice(0, MAX_ERROR_MESSAGE_CHARS),
    });
    logger.error("展开压缩包失败", {
      jobId,
      documentId: parent.id,
      code: appError.code,
      error: appError.message,
    });
    // 已经展开的子文档保留：它们是完整、可用的资料，没理由扔掉。
  }

  return children;
}

